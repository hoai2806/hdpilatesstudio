<?php
require_once 'config.php';
require_once 'functions.php';

$error_message = '';
$success_message = '';

// Xử lý thêm lịch tập
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $student_id = $_POST['student_id'];
    $instructor_id = $_POST['instructor_id'];
    $package_id = $_POST['package_id'];
    $date = $_POST['date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $type = $_POST['type'];
    $notes = $_POST['notes'];
    $repeat_type = $_POST['repeat_type'];
    $repeat_until = $_POST['repeat_until'];
    
    // Kiểm tra xung đột lịch
    $conflict = checkScheduleConflict($instructor_id, $date, $start_time, $end_time);
    
    // Kiểm tra số buổi tập còn lại
    $has_sessions = hasAvailableSessions($student_id, $package_id);
    
    if ($conflict) {
        $error_message = 'Huấn luyện viên đã có lịch tập trong thời gian này!';
    } elseif (!$has_sessions) {
        $error_message = 'Học viên đã hết số buổi tập trong gói!';
    } else {
        $sql = "INSERT INTO schedules (student_id, instructor_id, package_id, date, start_time, end_time, type, notes, repeat_type, repeat_until) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$student_id, $instructor_id, $package_id, $date, $start_time, $end_time, $type, $notes, $repeat_type, $repeat_until]);
        $success_message = 'Thêm lịch tập thành công!';
    }
}

// Lấy danh sách học viên
$sql = "SELECT id, name FROM students WHERE status = 'active' ORDER BY name";
$stmt = $conn->query($sql);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Lấy danh sách huấn luyện viên
$sql = "SELECT id, name FROM instructors WHERE status = 'active' ORDER BY name";
$stmt = $conn->query($sql);
$instructors = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Lấy danh sách gói tập
$sql = "SELECT id, name FROM packages WHERE status = 'active' ORDER BY name";
$stmt = $conn->query($sql);
$packages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Lấy danh sách lịch tập
$sql = "SELECT s.*, st.name as student_name, i.name as instructor_name, p.name as package_name 
        FROM schedules s 
        JOIN students st ON s.student_id = st.id 
        JOIN instructors i ON s.instructor_id = i.id 
        JOIN packages p ON s.package_id = p.id 
        ORDER BY s.date DESC, s.start_time DESC";
$stmt = $conn->query($sql);
$schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Lấy thông tin số buổi tập còn lại cho mỗi học viên
$student_packages = [];
foreach ($students as $student) {
    $student_packages[$student['id']] = getStudentPackageDetails($student['id']);
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý lịch tập - HD Pilates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">HD Pilates</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="students.php">Học viên</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="instructors.php">Huấn luyện viên</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="packages.php">Gói tập</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="schedules.php">Lịch tập</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Quản lý lịch tập</h2>
        
        <?php if ($error_message): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo $error_message; ?>
        </div>
        <?php endif; ?>

        <?php if ($success_message): ?>
        <div class="alert alert-success" role="alert">
            <?php echo $success_message; ?>
        </div>
        <?php endif; ?>

        <!-- Form thêm lịch tập -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Thêm lịch tập mới</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Học viên</label>
                                <select name="student_id" id="student_id" class="form-control" required>
                                    <option value="">Chọn học viên</option>
                                    <?php foreach ($students as $student): ?>
                                    <option value="<?php echo $student['id']; ?>"><?php echo htmlspecialchars($student['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Huấn luyện viên</label>
                                <select name="instructor_id" class="form-control" required>
                                    <option value="">Chọn huấn luyện viên</option>
                                    <?php foreach ($instructors as $instructor): ?>
                                    <option value="<?php echo $instructor['id']; ?>"><?php echo htmlspecialchars($instructor['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Gói tập</label>
                                <select name="package_id" id="package_id" class="form-control" required>
                                    <option value="">Chọn gói tập</option>
                                    <?php foreach ($packages as $package): ?>
                                    <option value="<?php echo $package['id']; ?>"><?php echo htmlspecialchars($package['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="text-muted" id="remaining_sessions"></small>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Ngày tập</label>
                                <input type="date" name="date" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Giờ bắt đầu</label>
                                <input type="time" name="start_time" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Giờ kết thúc</label>
                                <input type="time" name="end_time" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Loại buổi tập</label>
                                <select name="type" class="form-control" required>
                                    <option value="private">Cá nhân</option>
                                    <option value="group">Nhóm</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Ghi chú</label>
                                <textarea name="notes" class="form-control" rows="1"></textarea>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Lặp lại</label>
                                <select name="repeat_type" class="form-control" id="repeat_type">
                                    <option value="">Không lặp lại</option>
                                    <option value="daily">Hàng ngày</option>
                                    <option value="weekly">Hàng tuần</option>
                                    <option value="monthly">Hàng tháng</option>
                                </select>
                            </div>
                            <div class="mb-3" id="repeat_until_container" style="display: none;">
                                <label class="form-label">Lặp lại đến ngày</label>
                                <input type="date" name="repeat_until" class="form-control">
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="add" class="btn btn-primary">Thêm lịch tập</button>
                </form>
            </div>
        </div>

        <!-- Danh sách lịch tập -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Danh sách lịch tập</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Ngày</th>
                                <th>Thời gian</th>
                                <th>Học viên</th>
                                <th>Huấn luyện viên</th>
                                <th>Gói tập</th>
                                <th>Loại</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($schedules as $schedule): ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($schedule['date'])); ?></td>
                                <td><?php echo date('H:i', strtotime($schedule['start_time'])) . ' - ' . date('H:i', strtotime($schedule['end_time'])); ?></td>
                                <td><?php echo htmlspecialchars($schedule['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($schedule['instructor_name']); ?></td>
                                <td><?php echo htmlspecialchars($schedule['package_name']); ?></td>
                                <td><?php echo $schedule['type'] == 'private' ? 'Cá nhân' : 'Nhóm'; ?></td>
                                <td>
                                    <?php
                                    switch($schedule['status']) {
                                        case 'scheduled':
                                            echo '<span class="badge bg-primary">Đã đặt lịch</span>';
                                            break;
                                        case 'completed':
                                            echo '<span class="badge bg-success">Đã hoàn thành</span>';
                                            break;
                                        case 'cancelled':
                                            echo '<span class="badge bg-danger">Đã hủy</span>';
                                            break;
                                    }
                                    ?>
                                </td>
                                <td>
                                    <a href="edit_schedule.php?id=<?php echo $schedule['id']; ?>" class="btn btn-sm btn-primary">Sửa</a>
                                    <a href="delete_schedule.php?id=<?php echo $schedule['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Xóa</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Lưu trữ thông tin gói tập của học viên
    const studentPackages = <?php echo json_encode($student_packages); ?>;
    
    // Cập nhật thông tin số buổi tập còn lại
    function updateRemainingSessionsInfo() {
        const studentId = document.getElementById('student_id').value;
        const packageId = document.getElementById('package_id').value;
        const remainingSessionsElement = document.getElementById('remaining_sessions');
        
        if (studentId && packageId && studentPackages[studentId]) {
            const package = studentPackages[studentId].find(p => p.id == packageId);
            if (package) {
                const remaining = package.sessions - package.used_sessions;
                remainingSessionsElement.textContent = `Còn lại ${remaining} buổi tập`;
                remainingSessionsElement.className = remaining > 0 ? 'text-success' : 'text-danger';
            } else {
                remainingSessionsElement.textContent = '';
            }
        } else {
            remainingSessionsElement.textContent = '';
        }
    }
    
    // Thêm sự kiện lắng nghe cho các select
    document.getElementById('student_id').addEventListener('change', updateRemainingSessionsInfo);
    document.getElementById('package_id').addEventListener('change', updateRemainingSessionsInfo);
    
    // Xử lý hiển thị trường lặp lại
    const repeatTypeSelect = document.getElementById('repeat_type');
    const repeatUntilContainer = document.getElementById('repeat_until_container');
    
    repeatTypeSelect.addEventListener('change', function() {
        if (this.value) {
            repeatUntilContainer.style.display = 'block';
        } else {
            repeatUntilContainer.style.display = 'none';
        }
    });
    </script>
</body>
</html> 