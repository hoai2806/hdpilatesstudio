// Cấu hình chung cho biểu đồ
Chart.defaults.font.family = 'Roboto, sans-serif';
Chart.defaults.color = '#666';
Chart.defaults.plugins.legend.position = 'bottom';
Chart.defaults.plugins.legend.labels.boxWidth = 12;
Chart.defaults.plugins.legend.labels.padding = 20;

// Màu sắc cho biểu đồ
const chartColors = {
    primary: 'rgba(54, 162, 235, 0.5)',
    primaryBorder: 'rgb(54, 162, 235)',
    secondary: 'rgba(255, 206, 86, 0.5)',
    secondaryBorder: 'rgb(255, 206, 86)',
    success: 'rgba(75, 192, 192, 0.5)',
    successBorder: 'rgb(75, 192, 192)',
    danger: 'rgba(255, 99, 132, 0.5)',
    dangerBorder: 'rgb(255, 99, 132)',
    warning: 'rgba(255, 159, 64, 0.5)',
    warningBorder: 'rgb(255, 159, 64)',
    info: 'rgba(153, 102, 255, 0.5)',
    infoBorder: 'rgb(153, 102, 255)'
};

// Tạo biểu đồ cột
function createBarChart(canvasId, data, options = {}) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'bar',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: true,
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            ...options
        }
    });
}

// Tạo biểu đồ đường
function createLineChart(canvasId, data, options = {}) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'line',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: true,
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            ...options
        }
    });
}

// Tạo biểu đồ tròn
function createPieChart(canvasId, data, options = {}) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'pie',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            ...options
        }
    });
}

// Tạo biểu đồ bánh rán
function createDoughnutChart(canvasId, data, options = {}) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'doughnut',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            ...options
        }
    });
}

// Tạo biểu đồ radar
function createRadarChart(canvasId, data, options = {}) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'radar',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            ...options
        }
    });
}

// Cập nhật dữ liệu cho biểu đồ
function updateChartData(chart, newData) {
    chart.data = newData;
    chart.update();
}

// Thêm dữ liệu mới vào biểu đồ
function addChartData(chart, label, data) {
    chart.data.labels.push(label);
    chart.data.datasets.forEach((dataset, i) => {
        dataset.data.push(data[i]);
    });
    chart.update();
}

// Xóa dữ liệu khỏi biểu đồ
function removeChartData(chart) {
    chart.data.labels.pop();
    chart.data.datasets.forEach(dataset => {
        dataset.data.pop();
    });
    chart.update();
}

// Định dạng số tiền cho trục Y
function formatMoneyAxis(value) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND',
        maximumFractionDigits: 0
    }).format(value);
}

// Định dạng số cho trục Y
function formatNumberAxis(value) {
    return new Intl.NumberFormat('vi-VN').format(value);
}

// Định dạng phần trăm cho trục Y
function formatPercentAxis(value) {
    return value + '%';
}

// Tạo tooltip tùy chỉnh
function createCustomTooltip(tooltipItems) {
    let tooltip = '';
    tooltipItems.forEach(item => {
        const label = item.dataset.label || '';
        const value = item.raw;
        tooltip += `${label}: ${formatMoney(value)}\n`;
    });
    return tooltip;
}

// Tạo animation cho biểu đồ
function createChartAnimation(duration = 1000) {
    return {
        duration: duration,
        easing: 'easeInOutQuart',
        from: 0,
        to: 1
    };
}

// Tạo gradient cho biểu đồ
function createGradient(ctx, color1, color2) {
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, color1);
    gradient.addColorStop(1, color2);
    return gradient;
} 