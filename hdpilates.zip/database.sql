-- Tạo bảng users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff') NOT NULL DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tạo bảng students
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tạo bảng instructors
CREATE TABLE IF NOT EXISTS instructors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tạo bảng packages
CREATE TABLE IF NOT EXISTS packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('private', 'group') NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    sessions INT NOT NULL,
    duration INT NOT NULL COMMENT 'Duration in days',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tạo bảng schedules
CREATE TABLE IF NOT EXISTS schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    instructor_id INT NOT NULL,
    package_id INT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    type ENUM('private', 'group') NOT NULL,
    status ENUM('pending', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (instructor_id) REFERENCES instructors(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Thêm dữ liệu mẫu
INSERT INTO users (username, password, role) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

INSERT INTO students (name, email, phone, address) VALUES 
('Nguyễn Văn A', 'vana@example.com', '0123456789', '123 Đường ABC, Quận 1, TP.HCM'),
('Trần Thị B', 'thib@example.com', '0987654321', '456 Đường XYZ, Quận 2, TP.HCM');

INSERT INTO instructors (name, email, phone, address) VALUES 
('Lê Văn C', 'vanc@example.com', '0123456789', '789 Đường DEF, Quận 3, TP.HCM'),
('Phạm Thị D', 'thid@example.com', '0987654321', '321 Đường UVW, Quận 4, TP.HCM');

INSERT INTO packages (name, type, price, sessions, duration, description) VALUES 
('Gói cá nhân 1 tháng', 'private', 5000000, 12, 30, '12 buổi tập cá nhân trong 1 tháng'),
('Gói nhóm 1 tháng', 'group', 3000000, 12, 30, '12 buổi tập nhóm trong 1 tháng'),
('Gói cá nhân 3 tháng', 'private', 12000000, 36, 90, '36 buổi tập cá nhân trong 3 tháng'),
('Gói nhóm 3 tháng', 'group', 8000000, 36, 90, '36 buổi tập nhóm trong 3 tháng');

INSERT INTO schedules (student_id, instructor_id, package_id, date, time, type, status) VALUES 
(1, 1, 1, '2024-03-01', '09:00:00', 'private', 'completed'),
(2, 2, 2, '2024-03-01', '10:00:00', 'group', 'completed'),
(1, 1, 1, '2024-03-02', '09:00:00', 'private', 'completed'),
(2, 2, 2, '2024-03-02', '10:00:00', 'group', 'completed'); 