<?php
require_once 'config.php';

// Xử lý thêm huấn luyện viên
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $specialization = $_POST['specialization'];
    $experience = $_POST['experience'];
    
    $sql = "INSERT INTO instructors (name, email, phone, specialization, experience) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$name, $email, $phone, $specialization, $experience]);
}

// Lấy danh sách huấn luyện viên
$sql = "SELECT * FROM instructors ORDER BY name";
$stmt = $conn->query($sql);
$instructors = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý huấn luyện viên - HD Pilates</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">HD Pilates</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="students.php">Học viên</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="instructors.php">Huấn luyện viên</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="packages.php">Gói tập</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="schedules.php">Lịch tập</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Quản lý huấn luyện viên</h2>
        
        <!-- Form thêm huấn luyện viên -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Thêm huấn luyện viên mới</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Họ tên</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Số điện thoại</label>
                                <input type="tel" name="phone" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Chuyên môn</label>
                                <input type="text" name="specialization" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Số năm kinh nghiệm</label>
                                <input type="number" name="experience" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="add" class="btn btn-primary">Thêm huấn luyện viên</button>
                </form>
            </div>
        </div>

        <!-- Danh sách huấn luyện viên -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Danh sách huấn luyện viên</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Họ tên</th>
                                <th>Email</th>
                                <th>Số điện thoại</th>
                                <th>Chuyên môn</th>
                                <th>Kinh nghiệm</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($instructors as $instructor): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($instructor['name']); ?></td>
                                <td><?php echo htmlspecialchars($instructor['email']); ?></td>
                                <td><?php echo htmlspecialchars($instructor['phone']); ?></td>
                                <td><?php echo htmlspecialchars($instructor['specialization']); ?></td>
                                <td><?php echo htmlspecialchars($instructor['experience']); ?> năm</td>
                                <td>
                                    <a href="edit_instructor.php?id=<?php echo $instructor['id']; ?>" class="btn btn-sm btn-primary">Sửa</a>
                                    <a href="delete_instructor.php?id=<?php echo $instructor['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Xóa</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 